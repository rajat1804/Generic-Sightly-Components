


$(document).ready(function () {
$(".zoomdemo").elevateZoom({
  zoomType	: "inner",
  cursor: "crosshair"
});
});